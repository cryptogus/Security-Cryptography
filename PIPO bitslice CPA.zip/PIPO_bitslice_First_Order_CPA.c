
// First_Order_CPA.c
//

#include "PIPO_bitslice_Analysis.h"
#include "Table.h"
//left rotation: (0,7,4,3,6,5,1,2)
void pbox(unsigned char* X)
{
	X[1] = ((X[1] << 7)) | ((X[1] >> 1));
	X[2] = ((X[2] << 4)) | ((X[2] >> 4));
	X[3] = ((X[3] << 3)) | ((X[3] >> 5));
	X[4] = ((X[4] << 6)) | ((X[4] >> 2));
	X[5] = ((X[5] << 5)) | ((X[5] >> 3));
	X[6] = ((X[6] << 1)) | ((X[6] >> 7));
	X[7] = ((X[7] << 2)) | ((X[7] >> 6));
}

void sbox(unsigned char* X)
{
	unsigned char T[3] = { 0, };
	//(MSB: x[7], LSB: x[0]) 
	// Input: x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0] 
	//S5_1
	X[5] ^= (X[7] & X[6]);
	X[4] ^= (X[3] & X[5]);
	X[7] ^= X[4];
	X[6] ^= X[3];
	X[3] ^= (X[4] | X[5]);
	X[5] ^= X[7];
	X[4] ^= (X[5] & X[6]);
	//S3
	X[2] ^= X[1] & X[0];
	X[0] ^= X[2] | X[1];
	X[1] ^= X[2] | X[0];
	X[2] = ~X[2];
	// Extend XOR
	X[7] ^= X[1];	X[3] ^= X[2];	X[4] ^= X[0];
	//S5_2
	T[0] = X[7];	T[1] = X[3];	T[2] = X[4];
	X[6] ^= (T[0] & X[5]);
	T[0] ^= X[6];
	X[6] ^= (T[2] | T[1]);
	T[1] ^= X[5];
	X[5] ^= (X[6] | T[2]);
	T[2] ^= (T[1] & T[0]);
	// Truncate XOR and bit change
	X[2] ^= T[0];	T[0] = X[1] ^ T[2];	X[1] = X[0] ^ T[1];	X[0] = X[7];	X[7] = T[0];
	T[1] = X[3];	X[3] = X[6];	X[6] = T[1];
	T[2] = X[4];	X[4] = X[5];	X[5] = T[2];
	// Output: (MSb) x[7], x[6], x[5], x[4], x[3], x[2], x[1], x[0] (LSb)
}

int First_Order_CPA(struct tm *TIME, unsigned int POINTS, unsigned int TRACE_NUM)
{
	/************************************************************************************/
	/*                                     ���� ����                                    */
	/************************************************************************************/
	FILE			*fp									= NULL;
	FILE			*fp2								= NULL;
	FILE			*fpp								= NULL;
	FILE			*fpt								= NULL;

	char			FOLD_MERGE[_FILE_NAME_SIZE_]		= "";
	char			FILE_MERGE[_FILE_NAME_SIZE_]		= "";

	unsigned char	*Plaintext							= NULL;

	unsigned int	i									= 0;		// for (_BLOCK_SIZE, _CANDIDATES_)
	unsigned int	B									= 0;		// Byte
	unsigned int	Guess_Key							= 0;
	unsigned int	Key									= 0;
	unsigned int	Key_HW								= 0;
	unsigned int	R_Key								= 0;
	unsigned int	Right_Key							= 0;
	unsigned int	Index								= 0;
	unsigned int	Percent								= 0;
	unsigned int	Check								= 0;

	__int64			*H_S								= NULL;
	__int64			*H_SS								= NULL;
	__int64			tn									= 0;		// for (TN)
	__int64			pi									= 0;		// for (PI)
	__int64			TN									= 0;		// Trace Number
	__int64			PI									= 0;		// Point Interval

	float			F_Temp								= 0.;

	double			*Temp_Points						= NULL;
	double			*MaxPeak							= NULL;
	double			*W_CS								= NULL;
	double			*W_CSS								= NULL;
	double			**W_HS								= NULL;
	double			Correlation							= 0.;
	double			Correlation_L						= 0.;
	double			Correlation_R						= 0.;
	double			Max									= 0.;
	double			Max_Sec								= 0.;
	double			Ratio								= 0.;

	// �м��� ���� �� ����Ʈ �� ���
	TN = (__int64)_TRACE_NUM_;
	PI = (__int64)_END_POINT_ - (__int64)_START_POINT_ + (__int64)1;

	// �м��� ����Ʈ ��ġ ���
	B = _BYTE_ - 1;

	/************************************************************************************/
	/*                              ���� ���� �� ���� �˻�                              */
	/************************************************************************************/
	if (TRACE_NUM < TN) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                    �м� ���� ���� ����ġ �ʽ��ϴ�.                    |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}

	if (_START_POINT_ < 1 || _START_POINT_ > _END_POINT_) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                �м� ������ ���� ������ ����ġ �ʽ��ϴ�.               |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}

	if (_END_POINT_ > POINTS) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                 �м� ������ �� ������ ����ġ �ʽ��ϴ�.                |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}

	/************************************************************************************/
	/*                                   ���� �����Ҵ�                                   /
	/************************************************************************************/
	// �� ����
	Plaintext = (unsigned char *)malloc(_BLOCK_SIZE_ * sizeof(unsigned char));

	// �м� ����Ʈ ����
	Temp_Points = (double *)malloc((unsigned int)PI * sizeof(double));

	// �߰��� E[X] ����
	H_S = (__int64 *)malloc(_GUESS_KEY_NUM_ * sizeof(__int64));

	// �߰��� E[X^2] ����
	H_SS = (__int64 *)malloc(_GUESS_KEY_NUM_ * sizeof(__int64));

	// ���� ������ E[Y] ����
	W_CS = (double *)malloc((unsigned int)PI * sizeof(double));

	// ���� ������ E[Y^2] ���� 
	W_CSS = (double *)malloc((unsigned int)PI * sizeof(double));

	// E[XY] ����
	W_HS = (double **)malloc(_GUESS_KEY_NUM_ * sizeof(double *));
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		W_HS[Guess_Key] = (double *)malloc((unsigned int)PI * sizeof(double));
	}

	// �� Ű �ĺ��� �� MAXPEAK ����
	MaxPeak = (double *)malloc(_GUESS_KEY_NUM_ * sizeof(double));

	/************************************************************************************/
	/*                               First Order CPA ����                               */
	/************************************************************************************/
	// �� ���� ���� (�б� ���)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%s.txt", _FOLD_, _PLAIN_FILE_);
	fopen_s(&fpp, FILE_MERGE, "r");
	if (fpp == NULL) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                        Failed To Read Plaintext                       |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}

	// ���� ���� ���� (�б� ���)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%s.trace", _FOLD_, _TRACE_FILE_);
	fopen_s(&fpt, FILE_MERGE, "rb");
	if (fpt == NULL) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                          Failed To Read Trace                         |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}

	// ��� ������ ���� ����
	sprintf_s(FOLD_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%04d_%02d_%02d_%02d_%02d_%02d", _FOLD_, TIME->tm_year + 1900, TIME->tm_mon + 1, TIME->tm_mday, TIME->tm_hour, TIME->tm_min, TIME->tm_sec);
	_mkdir(FOLD_MERGE);

	// �� �ʱ�ȭ
	for (pi = 0; pi < PI; pi++) {
		W_CS[pi] = 0.0;
		W_CSS[pi] = 0.0;
		for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
			W_HS[Guess_Key][pi] = 0.0;
		}
	}
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		MaxPeak[Guess_Key] = 0;
		H_S[Guess_Key] = 0;
		H_SS[Guess_Key] = 0;
	}

	printf(" -----------------------------------------------------------------------\n");
	printf("|                            Loading Trace...                           |\n");
	printf(" -----------------------------------------------------------------------\n");

	for (tn = 0; tn < TN; tn++) {
		// ����� ǥ��
		Percent = (unsigned int)((double)tn / (double)TN * 100);
		if (Percent % 10 == 0 && Percent != 0 && Check != Percent) {
			printf("%d%%\t", Percent);
			if (Percent == 90) {
				printf("\n");
			}
			Check = Percent;
		}

		// �� �ҷ�����
		_fseeki64(fpp, ((__int64)_BLOCK_SIZE_ * (__int64)3 + (__int64)2) * (__int64)tn, SEEK_SET);
		for (i = 0; i < _BLOCK_SIZE_; i++) {
			fscanf_s(fpp, "%hhx", &Plaintext[i]);

		}
		
		// ����Ʈ �� �ҷ�����
		_fseeki64(fpt, 32 + ((__int64)POINTS * (__int64)tn + (__int64)_START_POINT_ - (__int64)1) * (__int64)4, SEEK_SET);
		for (pi = 0; pi < PI; pi++) {
			fread(&F_Temp, sizeof(float), 1, fpt);
			Temp_Points[pi] = (double)F_Temp;
		}

		// E[Y], E[Y^2] ���
		for (pi = 0; pi < PI; pi++) {
			W_CS[pi] += Temp_Points[pi];
			W_CSS[pi] += Temp_Points[pi] * Temp_Points[pi];
		}

		for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
			// �м� ��ġ
#if _TARGET_ == 0
			Key = Plaintext[B] ^ Guess_Key ^ RoundConstant; //��ȣ���� �޾ƿ͵� Plaintext ������ ���Ե�
#elif _TARGET_ == 1
			Key = PIPO_Sbox[Plaintext[B] ^ Guess_Key ^ RoundConstant];
#else
			printf(" -----------------------------------------------------------------------\n");
			printf("|                          Failed to Set Target                         |\n");
			printf(" -----------------------------------------------------------------------\n");
			return _FAIL_;
#endif

			// Hamming Weight ���
			Key_HW = (Key & 1) + ((Key >> 1) & 1) + ((Key >> 2) & 1) + ((Key >> 3) & 1) + ((Key >> 4) & 1) + ((Key >> 5) & 1) + ((Key >> 6) & 1) + ((Key >> 7) & 1);

			// E[X], E[X^2] ���
			H_S[Guess_Key]  += (__int64)Key_HW;
			H_SS[Guess_Key] += (__int64)(Key_HW * Key_HW);

			// E[XY] ���
			for (pi = 0; pi < PI; pi++) {
				W_HS[Guess_Key][pi] += (double)Key_HW * Temp_Points[pi];
			}
		}

#if _MAX_PEAK_TRACE_
		// Max Peak Trace ����
		if (!((tn + 1) % _TRACE_UNIT_)) {
			// Max Peak Trace ������ ���� ����
			sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_MAX_PEAK_UNIT_%d.txt", FOLD_MERGE, B + 1, _TRACE_UNIT_);
			fopen_s(&fp, FILE_MERGE, "a");

			for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
				for (pi = 0; pi < PI; pi++) {
					Correlation_L = (double)(tn + 1) * W_HS[Guess_Key][pi] - W_CS[pi] * (double)H_S[Guess_Key];
					Correlation_R = ((double)(tn + 1) * (double)H_SS[Guess_Key] - (double)H_S[Guess_Key] * (double)H_S[Guess_Key]) * ((double)(tn + 1) * W_CSS[pi] - W_CS[pi] * W_CS[pi]);

					if (Correlation_R <= (double)0) {
						Correlation = (double)0;
					}
					else {
						Correlation = Correlation_L / sqrt(Correlation_R);
						Correlation = fabs(Correlation);
					}

					if (MaxPeak[Guess_Key] < Correlation) {
						MaxPeak[Guess_Key] = Correlation;
					}
				}

				fprintf_s(fp, "%f ", MaxPeak[Guess_Key]);
			}

			fprintf_s(fp, "\n");

			fclose(fp);

			// �� �ʱ�ȭ
			for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
				MaxPeak[Guess_Key] = 0;
			}
		}
#endif
	}

	printf(" -----------------------------------------------------------------------\n");
	printf("|              Correlation Power Analysis On Key Candidates             |\n");
	printf(" -----------------------------------------------------------------------\n");

#if _CORRELATION_TRACE_
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d", FOLD_MERGE, B + 1);
	_mkdir(FILE_MERGE);
#endif

	// Ű�� ���� ������ ��� �� ��� �� ����
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
#if _CORRELATION_TRACE_
		sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d\\%03d(0x%02X).txt", FOLD_MERGE, B + 1, Guess_Key + _GUESS_KEY_START_, Guess_Key + _GUESS_KEY_START_);
		fopen_s(&fp, FILE_MERGE, "w");
#endif

		for (pi = 0; pi < PI; pi++) {
			Correlation_L = (double)TN * W_HS[Guess_Key][pi] - W_CS[pi] * (double)H_S[Guess_Key];
			Correlation_R = ((double)TN * (double)H_SS[Guess_Key] - (double)H_S[Guess_Key] * (double)H_S[Guess_Key]) * ((double)TN * W_CSS[pi] - W_CS[pi] * W_CS[pi]);

			if (Correlation_R <= (double)0) {
				Correlation = (double)0;
			}
			else {
				Correlation = Correlation_L / sqrt(Correlation_R);
				Correlation = fabs(Correlation);
			}

#if _CORRELATION_TRACE_
			fprintf_s(fp, "%f\n", Correlation);
#endif

			if (MaxPeak[Guess_Key] < Correlation) {
				MaxPeak[Guess_Key] = Correlation;

#if _GUESS_KEY_NUM_ == 1
				// ���� �м� ��� ����
				Index = (unsigned int)pi;

				sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_Result.txt", FOLD_MERGE, B + 1);
				fopen_s(&fp2, FILE_MERGE, "w");

				fprintf_s(fp2, "Point		: %d\n", Index + _START_POINT_);
				fprintf_s(fp2, "Correlation	: %f", MaxPeak[Guess_Key]);

				fclose(fp2);
#endif
			}
		}

#if _CORRELATION_TRACE_
		fclose(fp);
#endif
	}

#if _GUESS_KEY_NUM_ > 1
	// Guess Key Peak ����
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_GUESS_KEY_PEAK.txt", FOLD_MERGE, B + 1);
	fopen_s(&fp, FILE_MERGE, "w");

	// ���� �м� Ű ����
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_RIGHT_KEY.txt", FOLD_MERGE, B + 1);
	fopen_s(&fp2, FILE_MERGE, "w");

	Max = 0;
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		fprintf_s(fp, "%f\n", MaxPeak[Guess_Key]);

		if (Max < MaxPeak[Guess_Key]) {
			Max = MaxPeak[Guess_Key];
			R_Key = Guess_Key;
		}
	}

	fclose(fp);

	fprintf_s(fp2, "  1st  0x%02X  %f\n", R_Key, Max);

	MaxPeak[R_Key] = 0.0;

	for (i = 1; i < _CANDIDATES_; i++) {
		for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
			if (Max_Sec < MaxPeak[Guess_Key]) {
				Max_Sec = MaxPeak[Guess_Key];
				Right_Key = Guess_Key;
			}
		}

		if (i == 1) {
			fprintf_s(fp2, "  2nd  0x%02X  %f\n", Right_Key, Max_Sec);
			Ratio = Max / Max_Sec;
		}
		else if (i == 2) {
			fprintf_s(fp2, "  3rd  0x%02X  %f\n", Right_Key, Max_Sec);
		}
		else {
			fprintf_s(fp2, "%3dth  0x%02X  %f\n", i + 1, Right_Key, Max_Sec);
		}

		MaxPeak[Right_Key] = 0.0;
		Max_Sec = 0.0;
		Right_Key = 0;
	}

	fprintf_s(fp2, "\nRatio  %f\n", Ratio);

	fclose(fp2);
#endif


	fclose(fpp);
	fclose(fpt);

	/************************************************************************************/
	/*                                  ���� �Ҵ� ����                                  */
	/************************************************************************************/
	free(Plaintext);
	free(Temp_Points);
	free(H_S);
	free(H_SS);
	free(W_CS);
	free(W_CSS);
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		free(W_HS[Guess_Key]);
	}
	free(W_HS);
	free(MaxPeak);

	return _PASS_;
}
